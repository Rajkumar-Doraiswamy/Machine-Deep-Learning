# Last amended: 10th June, 2019
# My folder:  /home/ashok/Documents/4. transfer_learning

#
# Ref https://www.kaggle.com/dansbecker/exercise-data-augmentation
# https://www.kaggle.com/learn/deep-learning
# How the images were collected:
# Images were collected using facility available in Moodle at
#    http://203.122.28.230/moodle/mod/url/view.php?id=1768
# Or see:
#    https://addons.mozilla.org/en-US/firefox/addon/google-images-downloader/

# ResNet architecture is here:  http://ethereon.github.io/netscope/#/gist/db945b393d40bfa26006

# Objective:
#           Predict Rural-urban images with data augmentation using ResNet50

"""
Steps:
     i) Call libraries
    ii) Define necessary constants
   iii) Create ResNet model and classifier
   iv)  Compile model
    v)  Train-Data Augmentation:
             i) Define operations to be done on images--Configuration 1
            ii) Define from where to read images from,
                batch-size,no of classes, class-model  --Configuration 2
	vi) Validation data augmentation
	vii) Start training--Model fitting
    
"""



#    cp /home/ashok/.keras/keras_tensorflow.json  /home/ashok/.keras/keras.json
#    cat /home/ashok/.keras/keras.json
#    source activate tensorflow

######################### Call libraries
# 1. Call libraries
%reset -f

# 1.1 Application (ResNet50) library
# https://keras.io/applications/#resnet50
from keras.applications import ResNet50

# 1.2 Keras models and layers
from keras.models import Sequential

from keras.layers import Dense,  GlobalAveragePooling2D

# 1.3 Image generator and preprocessing
from keras.applications.resnet50 import preprocess_input
from keras.preprocessing.image import ImageDataGenerator

# 1.4 Misc
import time


######################### Define necessary constants

# 2. Constants & Modeling
num_classes = 2
image_size = 224      # Restrict image-sizes to uniform: 224 X 224

# 2.1 Image data folders
train_dir= '/home/ashok/Images/ruralurban/train'
val_dir = '/home/ashok/Images/ruralurban/val'


######################### Create ResNet model and classifier

# 2.2 Start model building
my_new_model = Sequential()

# 2.3
my_new_model.add(ResNet50(
                          include_top=False,        # No last softmax layer
                          pooling='avg',            # GlobalAveragePooling2D to flatten last convolution layer
                                                    #  See: https://www.quora.com/What-is-global-average-pooling
                          weights='imagenet'
                          )
                )

"""
Meaning of arguments
=====================
include_top = False
       whether to include the fully-connected layer at the top of the network.
pooling = 'avg'
       means that global average pooling will be
       applied to the output of the last convolutional layer,
       and thus the output of the model will be a 2D tensor.
       (2D includes batch_size also else it is just 1D)
weights:
       one of None (random initialization) or 'imagenet' (pre-training on ImageNet).

"""

# 2.4
my_new_model.summary()

# 2.5 Last output softmax layer
my_new_model.add(Dense(
                       num_classes,
                       activation='softmax'
                       )
                )

# 2.6
my_new_model.summary()

# 2.7 Say no to train first layer (ResNet) model.
#     It is already trained
my_new_model.layers[0]
my_new_model.layers[0].name
my_new_model.layers[0].trainable = False


# 3.0 Compile model
my_new_model.compile(
                     optimizer='sgd',
                     loss='categorical_crossentropy',
                     metrics=['accuracy']
                     )

######################### Train-Data Augmentation

# 3.1 Image processing and image generation
#     train data Image generator object
data_generator_with_aug = ImageDataGenerator(
                                             preprocessing_function=preprocess_input,      # keras image preprocessing function
                                             horizontal_flip=True,
                                             width_shift_range = 0.2,
                                             height_shift_range = 0.2
                                            )

# 3.2 No fit() needed
#     Create image data generator interator for train data
train_generator = data_generator_with_aug.flow_from_directory(
                                                              train_dir,
                                                              target_size=(image_size, image_size),
                                                              batch_size=32,
                                                              class_mode='categorical'
                                                              )


######################### Validation-Data Augmentation


# 3.3 validation data generator object
#     We will manipulate even Validation data also
#     Just to see if predictions are still made correctly
#     'data_generator_no_aug' is learner + ImageDataGenerator object
data_generator_no_aug = ImageDataGenerator(
                                           preprocessing_function=preprocess_input,
                                           rotation_range=90,
                                           horizontal_flip=True,
                                           vertical_flip=True,
                                           )


# 3.4 validation data image iterator
validation_generator = data_generator_no_aug.flow_from_directory(
                                                                 val_dir,
                                                                 target_size=(image_size, image_size),
                                                                 batch_size=32,
                                                                 class_mode='categorical'
                                                                 )


######################### Model fitting

# 4. Model fitting. Takes 8 minutes for epochs = 4
start = time.time()
history = my_new_model.fit_generator(
                           train_generator,
                           steps_per_epoch=4,     #  Total number of steps (batches of samples) to
                                                  #   yield from generator before declaring one epoch
                                                  #     finished and starting the next epoch.
                           epochs=10,             # All steps when finished, constitute one epoch
                           validation_data=validation_generator,
                           validation_steps=2,    #  Total number of steps (batches of samples) 
                                                  #   to yield from validation_data generator per epoch
                           workers = 1,           # Maximum number of processes to spin up
                           verbose = 1            # Show progress

                           )

end = time.time()
print("Time taken: ", (end - start)/60, "minutes")


# 5. Plot training accuracy and validation accuracy
import matplotlib.pyplot as plt
# 5.1
acc = history.history['acc']
vacc = history.history['val_acc']

# 5.2
# Get accuracy and validation accuracy data.
#  One data point per epoch
plt.plot(acc, label = "Train-acuracy")
plt.plot(vacc, label = "Val accuracy")
plt.legend()
plt.title("Train accuracy vs Validation accuracy")
plt.show()



###########################################################################



"""
 What does GlobalAveragePooling2D do?
 And what are its adavantages over normal FC layer?
  It takes overall average of every filter. So for a convolution layer
    with 32 filters, we will have a 1D layer with 32 neurons
     GlobalAveragePooling2D can, therefore, be used to flatten the last
      convolution layer. See also below at the end of this code.
      See: https://www.quora.com/What-is-global-average-pooling
	 : https://stats.stackexchange.com/a/308218

Effect of GlobalAveragePoolimg is that the last resnet50 layer is a flat layer
with 2048 neurons. See this link: http://ethereon.github.io/netscope/#/gist/db945b393d40bfa26006
The next layer is a dense layer with 2 neurons. Thus total number of weights are: 4098


_________________________________________________________________
Layer (type)                 Output Shape              Param #
=================================================================
resnet50 (Model)             (None, 2048)              23587712
_________________________________________________________________
dense_2 (Dense)              (None, 2)                 4098
=================================================================
Total params: 23,591,810
Trainable params: 4,098
Non-trainable params: 23,587,712


"""
